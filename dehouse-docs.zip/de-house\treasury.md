# Treasury

Policy:
- Diversified holdings (stablecoins, blue-chip assets)
- Runway planning, emergency buffers, and risk caps
- Periodic audits and public transparency reports

Operations:
- Controlled disbursements for build-outs, equipment, and events
- Yield strategies with conservative risk limits