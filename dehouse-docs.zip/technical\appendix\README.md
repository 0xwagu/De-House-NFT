# Technical Appendix

This appendix consolidates diagrams, canonical metadata schema, and cross-chain registry specifications used across the Protocol and De House systems.