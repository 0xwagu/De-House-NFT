# User Flow: Investor

- Discover asset series and read disclosures
- Complete KYC and be allowlisted
- Purchase fractional units during primary sale
- Receive distributions (stablecoins) pro-rata
- Optional: transfer units under compliance rules
- Track NAV updates via oracle feeds