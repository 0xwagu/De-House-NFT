# Governance

Structure:
- Multi-tier membership via keycards
- Proposals for space expansions, events, budgets
- Voting methods (1p1v, quadratic, tier-weighted)
- Execution via multisig and designated operators

Security:
- Timelocks for treasury movements
- Transparent on-chain records and public reporting